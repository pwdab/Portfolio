/* Creates 20 files in the root directory. */

#define FILE_CNT 20
#include "tests/filesys/extended/grow-dir.inc"
